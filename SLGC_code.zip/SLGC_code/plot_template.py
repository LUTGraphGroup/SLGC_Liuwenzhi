import numpy as np	# 加载数学库用于函数描述
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import style

matplotlib.rcParams['text.usetex'] = True  # 开启Latex风格
plt.figure(figsize=(10, 10), dpi=70)  # 设置图像大小
#style.use('ggplot')  # 加载'ggplot'风格
f, ax = plt.subplots(2, 2)  # 设置子图
plt.tight_layout() # 当有多个子图时，可以使用该语句保证各子图标题不会重叠
plt.savefig('myplot1.pdf', dpi=700) # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，输出位图文件
#plt.show() # 渲染图片
'''画单点图'''
def main():
    X = 1
    Y = 100
    plt.scatter(X, Y, s=50)	#s为点大小
    plt.show()
#main()

'''画散点图'''
def main1():
    X, Y = [], []#列表
    for i in range(1, 10):
        X.append(i)
        Y.append(np.sin(i))
    print(X,Y)
    plt.scatter(X, Y, s=50)#而scatter()中改变点的大小的参数是s：s=ms的平方
    plt.show()
#main1()

'''画散点连线图'''
def main2():
    X, Y = [], []
    for i in range(1, 10):
        X.append(i)
        Y.append(np.sin(i))
    #plt.plot(X, Y, ms=50)  #plot()中改变点的大小的参数是markersize 或 ms：
    plt.plot(X, Y, color='black',#线条颜色
             marker='o',#点的形状
             markersize=8, linewidth=2,#点的大小，线宽
             markerfacecolor='red',#点的颜色
             markeredgecolor='none',#点外框颜色
             markeredgewidth=2)#点边的宽度
    plt.show()
#main2()

def main3():
    X = np.linspace(1, 10, 100)	# 将[1,10]区间均分为100个点，得到100个横坐标
    Y = np.sin(X) # 求出100个点的纵坐标
    plt.plot(X, Y, color="red", linewidth=1.0, linestyle="-") # 将100个散点连在一起
    plt.show()#设置线条形状 linestyle 、线条宽度 linewidth 以及线条颜色 color
#main3()

'''接下来介绍常见的几种线条形状以及如何给线条加上标签
常见的 linestyle 还有 '-', '--', '-.', ':', 'solid', 'dashed', 'dashdot', 'dotted'，读者可以自行尝试。
常见的 legend 的 loc 位置还有 best, upper right, upper left, lower left, lower right, right, center left, 
center right, lower center, upper center, center，其中 best 表示将标签加载到 python 认为最佳的位置。
'''
def main4():
    X = np.linspace(1, 10, 100)
    Y1 = np.sin(X)
    Y2 = np.cos(X)
    Y3 = -X
    Y4 = X
    plt.plot(X, Y1, color="lightcoral", linewidth=3.0, linestyle="-", label="-")
    plt.plot(X, Y2, color="burlywood", linewidth=3.0, linestyle="--", label="--")
    plt.plot(X, Y3, color="mediumturquoise", linewidth=3.0, linestyle="-.", label="-.")
    plt.plot(X, Y4, color="mediumpurple", linewidth=3.0, linestyle=":", label=":")
    plt.legend(loc="best") # 把标签加载到图中哪个位置
    plt.show()
#main4()

'''
支持 Latex 的标签
由于是函数作图，因此我们通常会将标签设置为线条所代表的函数值，因此我们需要介绍支持 Latex 的标签。
我们将 label 的数值设置为 r'$x_n$' 即可支持 Latex，如下图所示。
'''
def main5():
    X = np.linspace(0, 1, 100)
    Y1 = np.sqrt(X)
    Y2 = X
    Y3 = X * X
    Y4 = X * X * X
    plt.plot(X, Y1, color="lightcoral", linewidth=3.0, linestyle="-", label=r"$y_1=\sqrt{x}$")
    plt.plot(X, Y2, color="burlywood", linewidth=3.0, linestyle="--", label=r"$y_2=x$")
    plt.plot(X, Y3, color="mediumturquoise", linewidth=3.0, linestyle="-.", label=r"$y_3=x^2$")
    plt.plot(X, Y4, color="mediumpurple", linewidth=3.0, linestyle=":", label=r"$y_4=x^3$")
    plt.legend(loc="best")
    plt.show()
#main5()

'''
设置横纵坐标标号以及图像标题
最后我们需要介绍如何给该图像设置横纵坐标、范围以及标题。我们首先不设置范围，则具体代码以及输出图形如下。'''
def main6():
    X = np.linspace(0, 1, 100)
    Y1 = np.sqrt(X)
    Y2 = X
    Y3 = X * X
    Y4 = X * X * X
    plt.plot(X, Y1, color="lightcoral", linewidth=3.0, linestyle="-", label=r"$y_1=\sqrt{x}$")
    plt.plot(X, Y2, color="burlywood", linewidth=3.0, linestyle="--", label=r"$y_2=x$")
    plt.plot(X, Y3, color="mediumturquoise", linewidth=3.0, linestyle="-.", label=r"$y_3=x^2$")
    plt.plot(X, Y4, color="mediumpurple", linewidth=3.0, linestyle=":", label=r"$y_4=x^3$")
    plt.legend(loc="best")

    # x、y坐标以及标题
    plt.xlabel('x', fontsize=18)
    plt.ylabel('y', fontsize=18)
    plt.title(r'$f(x)=\sqrt{x},x,x^2,x^3$', fontsize=18)
    plt.show()
#main6()

'''
设置横纵坐标的范围
有的时候我们会觉得系统默认的横纵坐标范围不合适，因此我们需要自行设置横纵坐标，具体代码以及结果如下所示。
'''
def main7():
    X = np.linspace(0, 2, 100)
    Y1 = np.sqrt(X)
    Y2 = X
    Y3 = X * X
    Y4 = X * X * X
    plt.plot(X, Y1, color="lightcoral", linewidth=3.0, linestyle="-", label=r"$y_1=\sqrt{x}$")
    plt.plot(X, Y2, color="burlywood", linewidth=3.0, linestyle="--", label=r"$y_2=x$")
    plt.plot(X, Y3, color="mediumturquoise", linewidth=3.0, linestyle="-.", label=r"$y_3=x^2$")
    plt.plot(X, Y4, color="mediumpurple", linewidth=3.0, linestyle=":", label=r"$y_4=x^3$")
    plt.legend(loc="best")

    # x、y坐标以及标题
    plt.xlabel('x', fontsize=18)
    plt.ylabel('y', fontsize=18)
    plt.title(r'$f(x)=\sqrt{x},x,x^2,x^3$', fontsize=18)

    # 设置坐标范围
    plt.ylim(-1, 4)
    plt.xlim(-1, 4)
    plt.show()
#main7()

'''
给函数中的一个点标号
当函数比较复杂的时候，我们往往需要对关键点进行标号，通常使用的方式是加箭头或者不加，我们先给出加箭头的代码以及结果。
'''
def main8():
    X = np.linspace(0, 1, 100)
    Y1 = np.sqrt(X)
    Y2 = X
    Y3 = X * X
    Y4 = X * X * X
    plt.plot(X, Y1, color="lightcoral", linewidth=3.0, linestyle="-", label=r"$y_1=\sqrt{x}$")
    plt.plot(X, Y2, color="burlywood", linewidth=3.0, linestyle="--", label=r"$y_2=x$")
    plt.plot(X, Y3, color="mediumturquoise", linewidth=3.0, linestyle="-.", label=r"$y_3=x^2$")
    plt.plot(X, Y4, color="mediumpurple", linewidth=3.0, linestyle=":", label=r"$y_4=x^3$")
    plt.legend(loc="best")

    # x、y坐标以及标题
    plt.xlabel('x', fontsize=18)
    plt.ylabel('y', fontsize=18)
    plt.title(r'$f(x)=\sqrt{x},x,x^2,x^3$', fontsize=18)

# 关键点标号
    plt.scatter(1, 1, s=100)#点的位置及大小
    plt.ylim(-1, 2)#设置y轴的范围
    plt.annotate('End Point', fontsize=20,#fontsize表示End Point字体大小
                 xy=(1, 1), xycoords='data',
                 xytext=(0.8, 0.95), textcoords='axes fraction',
                 arrowprops=dict(facecolor='black', shrink=0.1),
                 horizontalalignment='right', verticalalignment='top')
#其中 xy(1,1) 表示关键点的位置，xycoords='data' 表示关键点坐标所采用的坐标方式，
#shrink参数表示箭头距离关键点的距离，horizontalalignment='right', verticalalignment='top' 均表示注释的位置。
    plt.show()
#main8()

'''
也可以使用不加箭头的方式，即将上述 annotate 换成下述代码即可。
'''
def main9():
    X = np.linspace(0, 1, 100)
    Y1 = np.sqrt(X)
    Y2 = X
    Y3 = X * X
    Y4 = X * X * X
    plt.plot(X, Y1, color="lightcoral", linewidth=3.0, linestyle="-", label=r"$y_1=\sqrt{x}$")
    plt.plot(X, Y2, color="burlywood", linewidth=3.0, linestyle="--", label=r"$y_2=x$")
    plt.plot(X, Y3, color="mediumturquoise", linewidth=3.0, linestyle="-.", label=r"$y_3=x^2$")
    plt.plot(X, Y4, color="mediumpurple", linewidth=3.0, linestyle=":", label=r"$y_4=x^3$")
    plt.legend(loc="best")

    # x、y坐标以及标题
    plt.xlabel('x', fontsize=18)
    plt.ylabel('y', fontsize=18)
    plt.title(r'$f(x)=\sqrt{x},x,x^2,x^3$', fontsize=18)

# 关键点标号
    plt.scatter(1, 1, s=100)
    plt.ylim(-0.1, 1.3)
    plt.xlim(-0.1, 1.3)
    plt.annotate("End Point",
                 xy=(1.05, 1.05),#end point的位置
                 fontsize=20,
                 xycoords="data")
    plt.show()
#main9()

'''
子图
最后是如何用python画子图，其实画子图就是将上述的plt换成ax，具体操作的思路与之前的操作并没有太大的区别，
接下来给出一个包含横纵坐标、函数坐标、标题的完整子图代码，读者可以从代码中获取相应操作的代码。
'''
#style.use('ggplot')  # 加载'ggplot'风格
# matplotlib.rcParams['text.usetex'] = True  # 开启Latex风格
# plt.figure(figsize=(10, 10), dpi=70)  # 设置图像大小
# f, ax = plt.subplots(2, 2)  # 设置子图,2*2子图

'''另外，也可以使用 plt.sca() 来定位子图，如下述例子：'''
# f, ax = plt.subplots(2, 3, figsize=(15, 10)) # 声明 2 行 3 列的子图
# f.suptitle("设置总标题", fontsize=18)
# plt.sca(ax[0, 1]) # 定位到第 1 行第 2 列的子图
# # 接下来直接使用 plt 画图即可


def func1():
    X = np.linspace(0, 1, 100)
    Y1 = np.sqrt(X)
    # ax[0][0]的设置
    ax[0][0].plot(X, Y1, color="lightcoral", linewidth=3.0, linestyle="-", label=r"$y_1=\sqrt{x}$")
    ax[0][0].set_xlabel('x', fontsize=10)
    ax[0][0].set_ylabel('y', fontsize=10)
    ax[0][0].set_title(r'$f(x)=\sqrt{x}$', fontsize=16)
    ax[0][0].legend(loc="best")

    # ax[0][0]关键点
    ax[0][0].scatter(0.5, np.sqrt(0.5), s=100)
    ax[0][0].annotate("End Point",
                      xy=(0.6, 0.5),
                      fontsize=12,
                      xycoords="data")

def func2():
    X = np.linspace(0, 1, 100)
    Y2 = X
    # ax[0][1]的设置
    ax[0][1].plot(X, Y2, color="burlywood", linewidth=3.0, linestyle="--", label=r"$y_2=x$")
    ax[0][1].set_xlabel('x', fontsize=10)
    ax[0][1].set_ylabel('y', fontsize=10)
    ax[0][1].set_title(r'$f(x)=x$', fontsize=16)
    ax[0][1].legend(loc="best")

    # ax[0][1]关键点
    ax[0][1].scatter(0.5, 0.5, s=100)
    ax[0][1].annotate("End Point",
                      fontsize=12,
                      xytext=(0.7, 0.1),
                      xy=(0.5, 0.5),
                      xycoords="data",
                      arrowprops=dict(facecolor='gray', shrink=0.15))
def func3():
    X = np.linspace(0, 1, 100)
    Y3 = X * X
    # ax[1][0]的设置
    ax[1][0].plot(X, Y3, color="mediumturquoise", linewidth=3.0, linestyle="-.", label=r"$y_3=x^2$")
    ax[1][0].set_xlabel('x', fontsize=10)
    ax[1][0].set_ylabel('y', fontsize=10)
    ax[1][0].set_title(r'$f(x)=x^2$', fontsize=16)
    ax[1][0].legend(loc="best")

    # ax[1][0]关键点
    ax[1][0].scatter(0.5, 0.5 * 0.5, s=100)
    ax[1][0].annotate("End Point",
                      fontsize=12,
                      xytext=(0.05, 0.6),
                      xy=(0.5, 0.5 * 0.5),
                      xycoords="data",
                      arrowprops=dict(facecolor='black', shrink=0.1))

def func4():
    X = np.linspace(0, 1, 100)
    Y4 = X * X * X
    # ax[1][1]的设置
    ax[1][1].plot(X, Y4, color="mediumpurple", linewidth=3.0, linestyle=":", label=r"$y_4=x^3$")
    ax[1][1].set_xlabel('x', fontsize=10)
    ax[1][1].set_ylabel('y', fontsize=10)
    ax[1][1].set_title(r'$f(x)=x^3$', fontsize=16)
    ax[1][1].legend(loc="best")

    # ax[1][1]关键点
    ax[1][1].scatter(0.5, 0.5 * 0.5 * 0.5, s=100)
    ax[1][1].annotate("End Point",
                      xy=(0.2, 0.3),
                      fontsize=12,
                      xycoords="data")

def main10():
    func1()
    func2()
    func3()
    func4()

    # plt.tight_layout()  # 当有多个子图时，可以使用该语句保证各子图标题不会重叠
    # plt.savefig('myplot1.pdf', dpi=700)  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，输出位图文件
    plt.show()


if __name__ == "__main__":
    main10()

