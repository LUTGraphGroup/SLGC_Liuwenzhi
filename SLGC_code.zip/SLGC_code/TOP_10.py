import pandas as pd
import random
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy.stats import kendalltau

'''读取MATLAB中的邻接矩阵Excel文件'''
# G = nx.read_gml("data/Dolphins.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)
# nx.draw(G,node_size=500,with_labels=True)
# plt.show()
# print(nx.is_connected(G))

# G1 = nx.read_gml("data/Jazz.gml", label='id')
# A1 = nx.to_scipy_sparse_array(G1).todense()#构造邻接矩阵
# G1 = nx.to_networkx_graph(A1)
#
#
# G2 = nx.read_gml("data/USAir.gml", label='id')
# A2 = nx.to_scipy_sparse_array(G2).todense()#构造邻接矩阵
# G2 = nx.to_networkx_graph(A2)
#
#
# MM3 = pd.read_excel("data/EEC.xlsx",header=None)
# N3 = nx.from_numpy_matrix(np.array(MM3))
# A3 = nx.to_scipy_sparse_array(N3).todense()#构造邻接矩阵
# G3 = nx.to_networkx_graph(A3)
#
#
# G5 = nx.read_gml("data/Email.gml", label='id')
# A5 = nx.to_scipy_sparse_array(G5).todense()#构造邻接矩阵
# G5 = nx.to_networkx_graph(A5)
#
#
# MM6 = pd.read_excel("data/Stelzl.xlsx",header=None)
# N6 = nx.from_numpy_matrix(np.array(MM6))
# A6 = nx.to_scipy_sparse_array(N6).todense()#构造邻接矩阵
# G6 = nx.to_networkx_graph(A6)
#
#
# MM7 = pd.read_excel("data/Hamster.xlsx",header=None)
# N7 = nx.from_numpy_matrix(np.array(MM7))
# A7 = nx.to_scipy_sparse_array(N7).todense()#构造邻接矩阵
# G7 = nx.to_networkx_graph(A7)
#
# MM10 = pd.read_excel("data/Facebook.xlsx",header=None)
# N10 = nx.from_numpy_matrix(np.array(MM10))
# A10 = nx.to_scipy_sparse_array(N10).todense()#构造邻接矩阵
# G10 = nx.to_networkx_graph(A10)

MM11 = pd.read_excel("data/PGP.xlsx", header=None)
N11 = nx.from_numpy_matrix(np.array(MM11))
A11 = nx.to_scipy_sparse_array(N11).todense()  # 构造邻接矩阵
G11 = nx.to_networkx_graph(A11)

'''求距离矩阵'''


def distance(G):
    length = dict(nx.all_pairs_shortest_path_length(G))
    # print(length)
    distance_matrix = np.zeros([len(G), len(G)])
    for key1, value1 in length.items():
        for key2, value2 in value1.items():
            distance_matrix[key1][key2] = length[key1][key2]
    return distance_matrix


# result = pd.DataFrame(distance(G))
# result.to_excel('output/distance_matrix.xlsx',index=False)
'''求K核值'''


def k_shell(G):
    '''计算每个节点的KS值'''
    G1 = G.copy()  # 目的是对G1进行删点和边的操作，对G没有影响

    def k_shell_1(G1):
        importance_dict = {}
        level = 1
        while len(G1.degree):
            importance_dict[level] = []
            while True:
                level_node_list = []
                for item in G1.degree:
                    if item[1] <= level:
                        level_node_list.append(item[0])
                G1.remove_nodes_from(level_node_list)  # 从G中移除节点，移除完后为空，导致后续函数调用G报列表索引越界，k_sheel(G)放到最后
                importance_dict[level].extend(level_node_list)
                if not len(G1.degree):
                    return importance_dict
                if min(G1.degree, key=lambda x: x[1])[1] > level:
                    break
            level = min(G1.degree, key=lambda x: x[1])[1]
        # print('importance_dict',importance_dict)
        return importance_dict

    a = k_shell_1(G1)
    # print('a',a)
    H = {}
    for x, y in a.items():
        for z in y:
            H[z] = x
    # print('H',H)
    H_reverse = sorted(H.items(), key=lambda x: x[0])
    # print(dict(H_reverse))
    KS1 = list(dict(H_reverse).values())
    # print('KS1',KS1)
    return KS1


# print(k_shell(G))
'''求节点度'''


def node_degree(G):
    '''求度序列'''
    D1 = nx.degree(G)
    # print('D1=',D1)
    D = []  # D存放每个节点的di值
    for i in range(len(G)):
        D.append(D1[i])
    # print('D=', D)
    return D


'''求节点的聚类系数'''


def Cluster(G):
    C = nx.clustering(G)
    CL = []
    for i in C.values():
        CL.append(i)
    return CL


def dis_average(G):
    d6 = list(nx.all_pairs_shortest_path_length(G))  # 所有节点对之间的最短路径长度
    # print('d6',d6)
    a = []
    for n in range(len(G.nodes)):
        a1 = d6[n][1]
        # print('a1',a1)
        for k in a1.values():
            a.append(k)
    # print(a)
    total = 0
    for i in range(len(a)):
        total = total + a[i]
    dis_average = total / (len(G) * (len(G) - 1))
    # print('连通图或者非连通图的平均距离', dis_average)
    return dis_average


def degree(G):
    # 计算度中心性,降序
    dc = nx.algorithms.centrality.degree_centrality(G)
    # print('dc',dc)
    dc_reverse = dict(sorted(dc.items(), key=lambda x: x[1], reverse=True))
    # print('dc_reverse',dc_reverse)
    dc_1 = [i + 1 for i in list(dc_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1',dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('DC',degree(G))

def betweenness(G):
    # 计算介数中心性,降序
    dc = nx.betweenness_centrality(G)
    # print('dc',dc)
    dc_reverse = dict(sorted(dc.items(), key=lambda x: x[1], reverse=True))
    # print('dc_reverse',dc_reverse)
    dc_1 = [i + 1 for i in list(dc_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1',dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('BC',betweenness(G))

def closeness(G):
    # 计算接近中心性,降序
    dc = nx.closeness_centrality(G)
    # print('dc',dc)
    dc_reverse = dict(sorted(dc.items(), key=lambda x: x[1], reverse=True))
    # print('dc_reverse',dc_reverse)
    dc_1 = [i + 1 for i in list(dc_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1',dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('CC',closeness(G))

def CLD(G, A):
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=', M)
    DM = [0] * len(G)
    for i in range(len(G)):
        for j in range(len(G)):
            if A[i, j] == 1:
                DM[i] += M[j]
    # print('DM',DM)
    C = []
    for i in range(len(G)):
        C.append(nx.clustering(G, i))  # 计算每个节点的聚类系数
    # print('C',C)
    CLD = []
    for i in range(len(G)):
        CLD.append((1 + C[i]) * DM[i])
    # print('CLD', CLD)
    CLD_normalized = []
    for i in range(len(G)):
        CLD_normalized.append(CLD[i] / max(CLD))
    # print('CLD_normalized',CLD_normalized)
    dict1 = dict(enumerate(CLD_normalized))  # 将列表转化为字典
    # print('dict1',dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse',CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('CLD',CLD(G,A))


def QLC(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append(j ** 2 + j + 2 * W[i])
    C_normalized = []
    for i in range(len(A)):
        C_normalized.append(C[i] / max(C))  # 归一化，除最大值
    # print('C',C)
    # print('C_normalized', C_normalized)
    dict1 = dict(enumerate(C_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('QLC',QLC(G,A))

def GSM(G):
    '''求SI'''
    dis = distance(G)
    ks = k_shell(G)
    SI = []
    for i in range(len(G)):
        SI.append(math.exp(ks[i] / len(G)))
    # print('SI',SI)
    '''求GI'''
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += ks[j] / dis[i][j]
        GI.append(SS)
    # print('GI',GI)
    '''求GSM'''
    GSM = []
    for i in range(len(G)):
        GSM.append(SI[i] * GI[i])
    # print('GSM',GSM)
    GSM_normalized = []
    for i in range(len(GSM)):
        GSM_normalized.append(GSM[i] / max(GSM))  # 归一化，除最大值
    dict1 = dict(enumerate(GSM_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('GSM',GSM(G))

def KSGC(G):
    k = node_degree(G)
    # print(k)
    ks = k_shell(G)
    # print(ks)
    ks_max = max(ks)
    ks_min = min(ks)
    # print(ks_max, ks_min)
    dis = distance(G)
    # print(dis)
    dis_aver = dis_average(G)
    # print(dis_aver)

    ks_1 = ks_max - ks_min
    # print(ks_1)
    c = np.zeros([len(G), len(G)])
    for i in range(len(G)):
        for j in range(len(G)):
            c[i][j] = math.exp((ks[i] - ks[j]) / ks_1)
    # print('C', c)

    F = np.zeros([len(G), len(G)])
    for i in range(len(G)):
        for j in range(len(G)):
            if i == j or dis[i][j] == 0:
                F[i][j] = 0
            else:
                F[i][j] = c[i][j] * (k[i] * k[j] / dis[i][j] ** 2)
    # print('F', F)

    KSGC = []
    for i in range(len(G)):
        F1 = 0
        for j in range(len(G)):
            if dis[i][j] <= 0.5 * dis_aver:
                F1 += F[i][j]
        KSGC.append(F1)
    # print(KSGC)
    CLD_normalized = []
    for i in range(len(G)):
        CLD_normalized.append(KSGC[i] / max(KSGC))
    # print('CLD_normalized',CLD_normalized)
    dict1 = dict(enumerate(CLD_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print(KSGC(G))

def ALSI(G):
    k = node_degree(G)
    # print('度', k)
    ks = k_shell(G)
    # print('K核', ks)
    ks_max = max(ks)
    ks_min = min(ks)
    # print('ks_max', ks_max, 'ks_min', ks_min)

    neighb = []
    for i in G.nodes:
        list1 = list(G.neighbors(i))
        neighb.append(list1)

    # print(neighb)

    def jaccard(a, b):
        A1 = len(set(a).union(set(b)))
        B1 = len(set(a).intersection(set(b)))
        if A1 != 0:
            W = B1 / A1
        else:
            W = 0
        return W

    jaccard_matrix = np.zeros([len(G), len(G)])
    for i in range(len(G)):
        for j in range(len(G)):
            jaccard_matrix[i][j] = jaccard(neighb[i], neighb[j])
    # print('jaccard_matrix', jaccard_matrix)

    PP = []
    for i in range(len(G)):
        H = []
        for j in neighb[i]:
            H1 = ks[j] * jaccard_matrix[i][j] + k[j] * ks[j]
            if ks[j] < ks[i]:
                I = H1 / (ks_max + ks_min)
            elif ks[j] > ks[i]:
                I = H1 / (ks_max - ks_min)
            else:
                I = H1 / ks_max
            H.append(I)
        # print('H',H)
        PP.append(sum(H))
    # print('PP', PP)

    KK = []
    for i in range(len(G)):
        HH = k[i] + ks[i] / ks_max
        KK.append(HH)
    # print('KK', KK)

    total = []
    for i in range(len(G)):
        total.append(PP[i] / max(k) + KK[i])
    # print('total', total)

    ALSI_normalized = []
    for i in range(len(G)):
        ALSI_normalized.append(total[i] / max(total))
    # print('ALSI_normalized', ALSI_normalized)
    dict1 = dict(enumerate(ALSI_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


def generalized_centrality_Dolphins(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.4
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Dolphins',generalized_centrality_Dolphins(G,A))

def generalized_centrality_Jazz(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.7
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Jazz',generalized_centrality_Jazz(G,A))

def generalized_centrality_USAir(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.3
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('USAir',generalized_centrality_USAir(G,A))

def generalized_centrality_EEC(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.1
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('EEC',generalized_centrality_EEC(G,A))

def generalized_centrality_Email(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Email',generalized_centrality_Email(G,A))

def generalized_centrality_Stelzl(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.6
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Stelzl',generalized_centrality_Stelzl(G,A))

def generalized_centrality_Hamster(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.9
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Hamster',generalized_centrality_Hamster(G,A))

def generalized_centrality_Facebook(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.9
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print(generalized_centrality4(G,A))

def generalized_centrality_PGP(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = [i + 1 for i in list(CLD_reverse.keys())]  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print(generalized_centrality4(G,A))

def main1():
    H_1 = []
    H_1.extend([generalized_centrality_Dolphins(G, A), degree(G), betweenness(G), closeness(G), QLC(G, A),
                GSM(G), KSGC(G), ALSI(G)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='Dolphins', index=False)
    writer.close()


# print(main1())

def main2():
    H_1 = []
    H_1.extend([generalized_centrality_Jazz(G1, A1), degree(G1), betweenness(G1), closeness(G1),
                QLC(G1, A1), GSM(G1), KSGC(G1), ALSI(G1)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='Jazz', index=False)
    writer.close()


# print(main2())

def main3():
    H_1 = []
    H_1.extend([generalized_centrality_USAir(G2, A2), degree(G2), betweenness(G2), closeness(G2),
                QLC(G2, A2), GSM(G2), KSGC(G2), ALSI(G2)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='USAir', index=False)
    writer.close()


# print(main3())

def main4():
    H_1 = []
    H_1.extend([generalized_centrality_EEC(G3, A3), degree(G3), betweenness(G3), closeness(G3),
                QLC(G3, A3), GSM(G3), KSGC(G3), ALSI(G3)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='EEC', index=False)
    writer.close()


# print(main4())

def main5():
    H_1 = []
    H_1.extend([generalized_centrality_Facebook(G10, A10), degree(G10), betweenness(G10), closeness(G10),
                QLC(G10, A10), GSM(G10), KSGC(G10), ALSI(G10)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='Facebook', index=False)
    writer.close()


# print(main5())

def main6():
    H_1 = []
    H_1.extend([generalized_centrality_Email(G5, A5), degree(G5), betweenness(G5), closeness(G5),
                QLC(G5, A5), GSM(G5), KSGC(G5), ALSI(G5)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='Email', index=False)
    writer.close()


# print(main6())

def main7():
    H_1 = []
    H_1.extend([generalized_centrality_Stelzl(G6, A6), degree(G6), betweenness(G6), closeness(G6),
                QLC(G6, A6), GSM(G6), KSGC(G6), ALSI(G6)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='Stelzl', index=False)
    writer.close()


# print(main7())

def main8():
    H_1 = []
    H_1.extend([generalized_centrality_Hamster(G7, A7), degree(G7), betweenness(G7), closeness(G7),
                QLC(G7, A7), GSM(G7), KSGC(G7), ALSI(G7)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='Hamster', index=False)
    writer.close()


# print(main8())

def main9():
    H_1 = []
    H_1.extend([generalized_centrality_PGP(G11, A11), degree(G11), betweenness(G11), closeness(G11),
                QLC(G11, A11), GSM(G11), KSGC(G11), ALSI(G11)])  # generalized_centrality_Dolphins(G,A)不同网络不同，G，A也不同
    print(H_1)
    TOP10_matrix = np.zeros([10, len(H_1)])
    for i in range(len(H_1)):
        for j in range(10):
            TOP10_matrix[j][i] = H_1[i][j]
    print(TOP10_matrix)
    result = pd.DataFrame(TOP10_matrix)
    # 声明一个读写对象
    writer = pd.ExcelWriter("output/TOP10.xlsx", engine='openpyxl', mode='a')
    result.to_excel(writer, sheet_name='PGP', index=False)
    writer.close()


print(main9())
