import pandas as pd
import matplotlib
from matplotlib import style
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from generalized_centrality.get_generalized import *
import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
'''读取MATLAB中的邻接矩阵Excel文件'''
# G = nx.read_gml("data/Email.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)

MM = pd.read_excel("data/PGP.xlsx",header=None)
N = nx.from_numpy_matrix(np.array(MM))
A = nx.to_scipy_sparse_array(N).todense()#构造邻接矩阵
G = nx.to_networkx_graph(A)



H_1 = []
H_1.extend([degree(G), betweenness(G), closeness(G), CLD(G,A), QLC(G,A),
            GSM(G), KSGC(G),ALSI(G),generalized_centrality_PGP(G,A)])
X = []
for i in range(len(H_1)):
    X.append(len(CCDF(H_1[i])))
# print(max(X))
print('不同排名数', X)
result = pd.DataFrame(X)
#result.to_excel('output/SIR_Stelzl.xlsx',sheet_name="Stelzl",index=False)
#声明一个读写对象
writer=pd.ExcelWriter("output/Rank_number1.xlsx",engine='openpyxl',mode='a')
result.to_excel(writer,sheet_name='PGP',index=False)
#writer.save()#保存读写的内容
writer.close()