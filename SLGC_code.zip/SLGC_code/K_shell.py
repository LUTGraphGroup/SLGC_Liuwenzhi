import pandas as pd
import random
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy.stats import kendalltau

'''读取MATLAB中的邻接矩阵Excel文件'''
MM = pd.read_excel("test.xlsx",header=None)
N = nx.from_numpy_matrix(np.array(MM))
A = nx.to_scipy_sparse_array(N).todense()#构造邻接矩阵
G = nx.to_networkx_graph(A)

def k_shell_1(G):
    importance_dict = {}
    level = 1
    while len(G.degree):
        importance_dict[level] = []
        while True:
            level_node_list = []
            for item in G.degree:
                if item[1] <= level:
                    level_node_list.append(item[0])
            G.remove_nodes_from(level_node_list)  # 从G中移除节点，移除完后为空，导致后续函数调用G报列表索引越界，k_sheel(G)放到最后
            importance_dict[level].extend(level_node_list)
            if not len(G.degree):
                return importance_dict
            if min(G.degree, key=lambda x: x[1])[1] > level:
                break
        level = min(G.degree, key=lambda x: x[1])[1]
    # print('importance_dict',importance_dict)
    return importance_dict
#print(k_shell_1(G))
a=k_shell_1(G)
print('a',a)
H={}
for x , y in a.items():
    for z in y:
        H[z]=x
print('H',H)
H_reverse=sorted(H.items(), key=lambda x: x[0])
print(dict(H_reverse))
KS1=list(dict(H_reverse).values())
print('KS1',KS1)