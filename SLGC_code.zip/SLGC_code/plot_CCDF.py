import pandas as pd
import matplotlib
from matplotlib import style
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from generalized_centrality.get_generalized import *
import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch
import numpy as np
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

'''读取MATLAB中的邻接矩阵Excel文件'''
# G = nx.read_gml("data/Dolphins.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)
#
#
# G1 = nx.read_gml("data/Jazz.gml", label='id')
# A1 = nx.to_scipy_sparse_array(G1).todense()#构造邻接矩阵
# G1 = nx.to_networkx_graph(A1)
# #
# #
# G2 = nx.read_gml("data/USAir.gml", label='id')
# A2 = nx.to_scipy_sparse_array(G2).todense()#构造邻接矩阵
# G2 = nx.to_networkx_graph(A2)


# MM3 = pd.read_excel("data/EEC.xlsx",header=None)
# N3 = nx.from_numpy_matrix(np.array(MM3))
# A3 = nx.to_scipy_sparse_array(N3).todense()#构造邻接矩阵
# G3 = nx.to_networkx_graph(A3)


# MM4 = pd.read_excel("data/Roget.xlsx",header=None)
# N4 = nx.from_numpy_matrix(np.array(MM4))
# A4 = nx.to_scipy_sparse_array(N4).todense()#构造邻接矩阵
# G4 = nx.to_networkx_graph(A4)


# G5 = nx.read_gml("data/Email.gml", label='id')
# A5 = nx.to_scipy_sparse_array(G5).todense()#构造邻接矩阵
# G5 = nx.to_networkx_graph(A5)
#
# MM6 = pd.read_excel("data/Stelzl.xlsx",header=None)
# N6 = nx.from_numpy_matrix(np.array(MM6))
# A6 = nx.to_scipy_sparse_array(N6).todense()#构造邻接矩阵
# G6 = nx.to_networkx_graph(A6)
#
#
# MM7 = pd.read_excel("data/Hamster.xlsx",header=None)
# N7 = nx.from_numpy_matrix(np.array(MM7))
# A7 = nx.to_scipy_sparse_array(N7).todense()#构造邻接矩阵
# G7 = nx.to_networkx_graph(A7)


# MM8 = pd.read_excel("data/Power.xlsx",header=None)
# N8 = nx.from_numpy_matrix(np.array(MM8))
# A8 = nx.to_scipy_sparse_array(N8).todense()#构造邻接矩阵
# G8 = nx.to_networkx_graph(A8)


# MM9 = pd.read_excel("data/Yeast.xlsx",header=None)
# N9 = nx.from_numpy_matrix(np.array(MM9))
# A9 = nx.to_scipy_sparse_array(N9).todense()#构造邻接矩阵
# G9 = nx.to_networkx_graph(A9)

# MM10 = pd.read_excel("data/Facebook.xlsx",header=None)
# N10 = nx.from_numpy_matrix(np.array(MM10))
# A10 = nx.to_scipy_sparse_array(N10).todense()#构造邻接矩阵
# G10 = nx.to_networkx_graph(A10)
#
MM11 = pd.read_excel("data/PGP.xlsx", header=None)
N11 = nx.from_numpy_matrix(np.array(MM11))
A11 = nx.to_scipy_sparse_array(N11).todense()  # 构造邻接矩阵
G11 = nx.to_networkx_graph(A11)


# MM12 = pd.read_excel("data/Sex.xlsx",header=None)
# N12 = nx.from_numpy_matrix(np.array(MM12))
# A12 = nx.to_scipy_sparse_array(N12).todense()#构造邻接矩阵
# G12 = nx.to_networkx_graph(A12)

def main1():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G), betweenness(G), closeness(G), QLC(G, A),
                GSM(G), KSGC(G), ALSI(G), generalized_centrality_Dolphins(G, A)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A), len(A))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    ax1.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    ax1.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    ax1.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    ax1.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    ax1.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=7, markerfacecolor='y', label=r"GSM")
    ax1.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=8, markerfacecolor='lime', label=r"KSGC")
    ax1.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=4, markerfacecolor='b', label=r"ALSI")
    ax1.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=5, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Dolphins', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(10)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 65)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Dolphins.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main1()

def main2():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G1), betweenness(G1), closeness(G1), QLC(G1, A1),
                GSM(G1), KSGC(G1), ALSI(G1), generalized_centrality_Jazz(G1, A1)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A1) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A1), len(A1))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    # plt.figure(figsize=(6, 6))  # 图片尺寸大小
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=8, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=7, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=4, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=5, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Jazz', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(40)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 200)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  # 设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  # 设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  # 设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''

    # 绘制缩放图
    axins = inset_axes(ax1, width="36%", height="40%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
               marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    axins.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
               marker='X', markersize=8, markerfacecolor='y', label=r"GSM")
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=7, markerfacecolor='lime', label=r"KSGC")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=4, markerfacecolor='b', label=r"ALSI")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=5, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(185, 197)
    axins.set_ylim(-0.005, 0.06)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Jazz.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main2()

def main3():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G2), betweenness(G2), closeness(G2), QLC(G2, A2),
                GSM(G2), KSGC(G2), ALSI(G2), generalized_centrality_USAir(G2, A2)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A2) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A2), len(A2))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=5, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'USAir', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(50)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 300)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="36%", height="40%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
               marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=5, markerfacecolor='b', label=r"ALSI")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(260, 290)
    axins.set_ylim(-0.01, 0.1)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_USAir.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main3()

def main4():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G3), betweenness(G3), closeness(G3), QLC(G3, A3),
                GSM(G3), KSGC(G3), ALSI(G3), generalized_centrality_EEC(G3, A3)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A3) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A3), len(A3))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=7, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=5, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'EEC', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 1000)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="35%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
               marker='X', markersize=7, markerfacecolor='y', label=r"GSM")
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=4, markerfacecolor='b', label=r"ALSI")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=5, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(955, 965)
    axins.set_ylim(-0.001, 0.01)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_EEC.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main4()

def main5():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G4), betweenness(G4), closeness(G4), CLD(G4, A4), QLC(G4, A4),
                GSM(G4), LGC(G4), generalized_centrality_Roget(G4, A4)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A4) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A4), len(A4))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"CLD")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"QLC")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"GSM")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"LGC")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"GEEC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Roget', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 1050)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="35%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=8, markerfacecolor='lime', label=r"GSM")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=5, markerfacecolor='b', label=r"LGC")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=5, markerfacecolor='k', label=r"GEEC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(985, 995)
    axins.set_ylim(-0.001, 0.01)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Roget.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main5()

def main6():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G5), betweenness(G5), closeness(G5), QLC(G5, A5),
                GSM(G5), KSGC(G5), ALSI(G5), generalized_centrality_Email(G5, A5)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A5) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A5), len(A5))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=7, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=4, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Email', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 1200)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="35%", loc='upper left',
                       bbox_to_anchor=(0.39, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
               marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1102, 1108)
    axins.set_ylim(-0.0008, 0.005)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Email.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main6()

def main7():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G6), betweenness(G6), closeness(G6), QLC(G6, A6),
                GSM(G6), KSGC(G6), ALSI(G6), generalized_centrality_Stelzl(G6, A6)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A6) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A6), len(A6))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=5, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Stelzl', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 1300)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="36%", height="40%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
               marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1140, 1230)
    axins.set_ylim(-0.005, 0.06)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Stelzl.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main7()

def main8():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G7), betweenness(G7), closeness(G7), QLC(G7, A7),
                GSM(G7), KSGC(G7), ALSI(G7), generalized_centrality_Hamster(G7, A7)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A7) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A7), len(A7))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=7, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=4, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Hamster', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(300)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 1800)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="40%", height="40%", loc='upper left',
                       bbox_to_anchor=(0.36, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
               marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=7, markerfacecolor='lime', label=r"KSGC")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=4, markerfacecolor='b', label=r"ALSI")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1550, 1700)
    axins.set_ylim(-0.005, 0.06)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Hamster.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main8()

def main9():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G8), betweenness(G8), closeness(G8), CLD(G8, A8), QLC(G8, A8),
                GSM(G8), LGC(G8), generalized_centrality_Power(G8, A8)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A8) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A8), len(A8))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"CLD")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"QLC")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"GSM")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"LGC")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"GEEC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Power', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(900)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 4600)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="38%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=8, markerfacecolor='lime', label=r"GSM")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=5, markerfacecolor='b', label=r"LGC")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=5, markerfacecolor='k', label=r"GEEC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(4460, 4485)
    axins.set_ylim(-0.0005, 0.006)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Power.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main9()

def main10():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G9), betweenness(G9), closeness(G9), CLD(G9, A9), QLC(G9, A9),
                GSM(G9), LGC(G9), generalized_centrality_Yeast(G9, A9)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A9) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A9), len(A9))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"CLD")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"QLC")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"GSM")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"LGC")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"GEEC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Yeast', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(400)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 2000)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="38%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=8, markerfacecolor='lime', label=r"GSM")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=5, markerfacecolor='b', label=r"LGC")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=5, markerfacecolor='k', label=r"GEEC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1850, 1870)
    axins.set_ylim(-0.0005, 0.006)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Yeast.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main10()

def main11():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G10), betweenness(G10), closeness(G10), QLC(G10, A10),
                GSM(G10), KSGC(G10), ALSI(G10), generalized_centrality_Facebook(G10, A10)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A10) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A10), len(A10))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=7, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=5, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Facebook', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(800)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 4000)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="38%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
               marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=7, markerfacecolor='lime', label=r"KSGC")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=5, markerfacecolor='b', label=r"ALSI")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(3680, 3900)
    axins.set_ylim(-0.006, 0.06)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Facebook.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


# main11()

def main12():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G11), betweenness(G11), closeness(G11), QLC(G11, A11),
                GSM(G11), KSGC(G11), ALSI(G11), generalized_centrality_PGP(G11, A11)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A11) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A11), len(A11))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'PGP', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(1700)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(-150, 8700)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="38%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(7800, 8400)
    axins.set_ylim(-0.005, 0.06)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_PGP.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


main12()


def main13():
    # 读取数据
    H_1 = []
    H_1.extend([degree(G12), betweenness(G12), closeness(G12), CLD(G12, A12), QLC(G12, A12),
                GSM(G12), LGC(G12), generalized_centrality_Sex(G12, A12)])
    H_2 = H_1
    X = []
    Y1 = []
    for i in range(len(H_2)):
        Y1.append(CCDF(H_2[i]))
        X.append(len(CCDF(H_2[i])))
    # print(max(X))
    print('不同排名数', X)
    # print('Y1',Y1)
    Y2 = []
    for i, j in enumerate(Y1):  # i:索引 j：值
        j.extend(0 for _ in range(len(A12) - len(j)))  # 将每个i的长度设置为len(H_2[i])，不足的后面补0.
        Y2.append(j)
    # print('Y2',Y2)
    X2 = np.linspace(1, len(A12), len(A12))
    # print('X2',X2)

    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.plot(X2, Y2[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X2, Y2[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X2, Y2[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X2, Y2[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"CLD")
    plt.plot(X2, Y2[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"QLC")
    plt.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"GSM")
    plt.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"LGC")
    plt.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"GEEC")
    # # 绘制垂直于X轴的直线
    # plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("Rank", font)
    plt.ylabel("CCDF", font)
    plt.title(r'Sex', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(400)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 2000)
    plt.ylim(-0.05, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细

    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="upper right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="35%", height="38%", loc='upper left',
                       bbox_to_anchor=(0.40, 0.195, 0.8, 0.8),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.plot(X2, Y2[5], color="lime", linewidth=2, linestyle="-",
               marker='h', markersize=8, markerfacecolor='lime', label=r"GSM")
    axins.plot(X2, Y2[6], color="b", linewidth=2, linestyle="-",
               marker='s', markersize=5, markerfacecolor='b', label=r"LGC")
    axins.plot(X2, Y2[7], color="k", linewidth=2, linestyle="-",
               marker='o', markersize=5, markerfacecolor='k', label=r"GEEC")

    # 设置放大区间
    zone_left = 180
    zone_right = 195

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = X2[zone_left] - (X2[zone_right] - X2[zone_left]) * x_ratio
    xlim1 = X2[zone_right] + (X2[zone_right] - X2[zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((Y2[0][zone_left:zone_right], Y2[1][zone_left:zone_right],
                   Y2[2][zone_left:zone_right], Y2[3][zone_left:zone_right],
                   Y2[4][zone_left:zone_right], Y2[5][zone_left:zone_right],
                   Y2[6][zone_left:zone_right], Y2[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1850, 1870)
    axins.set_ylim(-0.0005, 0.006)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\CCDF_Sex.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# main13()
