import pandas as pd
import random
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy.stats import kendalltau
import xlrd as xd
from generalized_centrality.get_generalized import *

'''读取MATLAB中的邻接矩阵Excel文件'''
# G = nx.read_gml("data/Email.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)
# # nx.draw(G,node_size=500,with_labels=True)
# # plt.show()
# print(nx.is_connected(G))
# #print(generalized_centrality1(G,A))

MM = pd.read_excel("data/PGP.xlsx",header=None)
N = nx.from_numpy_matrix(np.array(MM))
A = nx.to_scipy_sparse_array(N).todense()#构造邻接矩阵
G = nx.to_networkx_graph(A)
# nx.draw(G,node_size=500,with_labels=True)
# plt.show()
print(nx.is_connected(G))

H_1 = generalized_centrality_parameter(G,A)

data = xd.open_workbook('data/data_set_1.xlsx')  # 打开excel表所在路径
sheet = data.sheet_by_name('PGP')  # 读取数据，以excel表名来打开
SIR = []
for r in range(sheet.ncols):  # 将表中数据按列逐步添加到列表中，最后转换为list结构
    data1 = []
    for c in range(sheet.nrows):
        data1.append(sheet.cell_value(c, r))
    SIR.append(list(data1))
# print("SIR", SIR)
# print(len(SIR))

SIR_matrix = np.zeros([len(H_1), len(SIR)])
for i in range(len(H_1)):
    for j in range(len(SIR)):
        SIR_matrix[i][j]=sckendall_1(H_1[i],SIR[j])
print(SIR_matrix)
result = pd.DataFrame(SIR_matrix)
#result.to_excel('output/SIR_Stelzl_parameter.xlsx',sheet_name="Stelzl",index=False)

#声明一个读写对象
writer=pd.ExcelWriter("output/参数实验.xlsx",engine='openpyxl',mode='a')
result.to_excel(writer,sheet_name='PGP',index=False)
#writer.save()#保存读写的内容
writer.close()


