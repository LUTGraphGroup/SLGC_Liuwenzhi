from generalized_energy.energy_EEC_rank import *


def CCDF(List):
    a = {}
    for i in List:
        if List.count(i) >= 1:
            a[i] = List.count(i)
    b = dict(sorted(a.items()))
    # print('a=',a)
    # print('b=',b)
    t = list(b.values())
    # print('t=',t)
    f = []
    for i in range(1, len(t) + 1, 1):
        f.append(sum(t[0:i]))  # sum对列表前i项进行求和
    # print('f=',f)
    CCDF = []
    for i in range(len(f)):
        CCDF.append(1 - (f[i] / len(List)))
    # print('CCDF=',CCDF)
    # print(len(CCDF))
    return CCDF
# CCDF(pagerank(G14))
# CCDF(generalized_centrality_Hamster(G14,A14))
