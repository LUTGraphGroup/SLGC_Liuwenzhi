#from generalized_energy.energy_EEC_rank import *

'''
排序单调性MR
'''
def MR(List):
    a = {}
    m=0
    for i in List:
        if List.count(i)>=1:
            a[i] = List.count(i)
    print('a=',a)
    N=len(a)
    print('N',N)
    for i in a:
        print('i',i)
        print('a[i]',a[i])
        m+=a[i]*(a[i]-1)
    M= (1-m/(N*(N-1))) ** 2
    #print(N,M)
    return(M)

List1=[1,2,2,3,4,4]
List2=[1,2,2,2,3,4]
print(MR(List1))
print(MR(List2))


# H_1 = []
# H_3 = []
# H_1.extend([degree(G), betweenness(G), closeness(G), pagerank(G), eigenvector(G1), CLD(G,A), k_shell(G,A),
#             ECL(G1,A1),generalized_centrality_dolphins(G1,A1)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('dolphins',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G2), betweenness(G2), closeness(G2), pagerank(G2), eigenvector(G2), CLD(G2,A2), k_shell(G2,A2),
#             ECL(G3,A3),generalized_centrality_JAZZ(G3,A3)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('JAZZ',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G4), betweenness(G4), closeness(G4), pagerank(G4), eigenvector(G4), CLD(G4,A4), k_shell(G4,A4),
#             ECL(G5,A5),generalized_centrality_USAIR(G5,A5)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('USAIR',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G6), betweenness(G6), closeness(G6), pagerank(G6), eigenvector(G6), CLD(G6,A6), k_shell(G6,A6),
#             ECL(G7,A7),generalized_centrality_EEC(G7,A7)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('EEC',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G8), betweenness(G8), closeness(G8), pagerank(G8), eigenvector(G8), CLD(G8,A8), k_shell(G8,A8),
#             ECL(G9,A9),generalized_centrality_Roget(G9,A9)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('Roget',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G10), betweenness(G10), closeness(G10), pagerank(G10), eigenvector(G10), CLD(G10,A10),
#             k_shell(G10,A10),ECL(G11,A11),generalized_centrality_Email(G11,A11)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('Email',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G12), betweenness(G12), closeness(G12), pagerank(G12), eigenvector(G12), CLD(G12,A12),
#             k_shell(G12,A12),ECL(G13,A13),generalized_centrality_Stelzl(G13,A13)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('Stelzl',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G14), betweenness(G14), closeness(G14), pagerank(G14), eigenvector(G14), CLD(G14,A14),
#             k_shell(G14,A14),ECL(G15,A15),generalized_centrality_Hamster(G15,A15)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('Hamster',H_3)
#
# H_1 = []
# H_3 = []
# H_1.extend([degree(G16), betweenness(G16), closeness(G16), pagerank(G16), eigenvector(G16), CLD(G16,A16),
#             k_shell(G16,A16),ECL(G17,A17),generalized_centrality_Power(G17,A17)])
# H_2 = H_1
# for i in H_2:
#     H_3.append(MR(i))
# print('Power',H_3)