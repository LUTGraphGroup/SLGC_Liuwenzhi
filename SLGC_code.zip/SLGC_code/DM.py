from generalized_centrality.get_generalized import *

'''读取MATLAB中的邻接矩阵Excel文件'''
# G = nx.read_gml("data/Dolphins.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)
# # nx.draw(G,node_size=500,with_labels=True)
# # plt.show()
# print(nx.is_connected(G))

MM = pd.read_excel("data/Facebook.xlsx", header=None)
N = nx.from_numpy_matrix(np.array(MM))
A = nx.to_scipy_sparse_array(N).todense()  # 构造邻接矩阵
G = nx.to_networkx_graph(A)
# nx.draw(G,node_size=500,with_labels=True)
# plt.show()
# print(nx.is_connected(G))

H_1 = []
H_1.extend([degree(G), betweenness(G), closeness(G), CLD(G, A), QLC(G, A),
            GSM(G), LGC(G),
            generalized_centrality_Facebook(G, A)])  # generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
# print('H_1',H_1)
H_2 = []
for i in H_1:
    H_2.append(DM(i))
print('Facebook', H_2)
result = pd.DataFrame(H_2)
# 声明一个读写对象
writer = pd.ExcelWriter("output/DM.xlsx", engine='openpyxl', mode='a')
result.to_excel(writer, sheet_name='Facebook', index=False)
# writer.save()#保存读写的内容
writer.close()
