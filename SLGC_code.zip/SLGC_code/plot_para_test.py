import numpy as np
import pandas as pd
import numpy as np	# 加载数学库用于函数描述
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import style
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
kendall = pd.read_excel('output/参数实验.xlsx', sheet_name='average', header=None)  # header=0删除了第一行
print(kendall)
Y = []
for i in range(kendall.shape[1]):  # 遍历列
    Y.append(list(kendall[i]))
print(Y)








def main1():
    # 读取数据
    kendall = pd.read_excel('output/参数实验.xlsx', sheet_name='average', header=None)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[1]):  # 遍历列
        Y.append(list(kendall[i]))
    print(Y)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0,1,11)
    #print(X)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"$Dolphins$")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
                  markersize=6, markerfacecolor='darkorange', label=r"$Jazz$")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
                  marker='P', markersize=6, markerfacecolor='g', label=r"$USAir$")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
                  marker='d', markersize=5, markerfacecolor='m', label=r"$EEC$")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
                  marker='X', markersize=6, markerfacecolor='y', label=r"$Roget$")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
                  marker='h', markersize=6, markerfacecolor='lime', label=r"$Email$")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
                  marker='s', markersize=6, markerfacecolor='b', label=r"$Stelzl$")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k',label=r"$Hamster$")
    plt.plot(X, Y[8], color="mediumturquoise", linewidth=2, linestyle="-.",
             marker='o', markersize=6, markerfacecolor='mediumturquoise', label=r"$Power$")
    # 绘制垂直于X轴的直线
    #plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 14,
            }
    plt.xlabel("$\\alpha$", font)
    plt.ylabel("$\\tau$", font)
    #plt.title(r'Dolphins',family='Times New Roman',fontsize=14,weight='bold')

    #plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14,family='Times New Roman',weight='bold')#设置坐标轴刻度字号
    plt.yticks(fontsize=14,family='Times New Roman',weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.2)  # 以每0.05显示
    #y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    #ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(-0.05, 1.05)
    plt.ylim(0.79, 0.93)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }#normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black',prop=font1,framealpha=1) # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\para_test.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
main1()