import numpy as np
import pandas as pd
import numpy as np  # 加载数学库用于函数描述
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import style
from matplotlib.ticker import MultipleLocator, FormatStrFormatter


def main1():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='Dolphins', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.1470], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')

    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    # plt.rcParams.update(font)
    # with plt.rc_context(font):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'Dolphins', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.5, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    # front是标签属性：包括字体、大小等
    # font1 = {'font.family': 'Times New Roman',
    #          'mathtext.fontset':'stix',
    #         'font.weight': 'bold',
    #         'font.size': 13,
    #         }#normal,bold,heavy,black
    # plt.rcParams.update(font1)#设置运行配置参数 rcParams （runtime configuration parameters）
    # with plt.rc_context(font1):#如果不想改变全局变量，可以使用 with 语句 + 上下文管理器函数 matplotlib.style.context 临时更改。
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_Dolphins.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main2():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='Jazz', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0259], 0.4, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'Jazz', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.4, 1)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_Jazz.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main3():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='USAir', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0225], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'USAir', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.55, 0.97)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_USAir.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main4():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='EEC', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0134], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'EEC', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.7, 0.95)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_EEC.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main6():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='Email', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0535], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'Email', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.6, 0.95)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_Email.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main7():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='Stelzl', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0594], 0.4, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'Stelzl', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.4, 0.9)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_Stelzl.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main8():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='Hamster', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0235], 0.5, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'Hamster', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.55, 0.95)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_Hamster.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main10():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='Facebook', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0094], 0.2, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'Facebook', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.35, 0.90)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_Facebook.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main11():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='PGP', header=0)  # header=0删除了第一行
    print(kendall)
    Y = []
    for i in range(kendall.shape[0]):  # 遍历行
        Y1 = []
        for j in range(kendall.shape[1]):  # 遍历列
            Y1.append(kendall[j][i])
        Y.append(Y1)
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.linspace(0.01, 0.20, 20)
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    plt.vlines([0.0530], 0.2, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'PGP', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(0.05)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0.0025, 0.205)
    plt.ylim(0.25, 0.80)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_PGP.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def averge_kendall():
    # 读取数据
    kendall = pd.read_excel('output/SIR_kendall_2.xlsx', sheet_name='Sheet2', header=0)  # header=0删除了第一行
    print('kendall', kendall)
    Y = kendall.values.tolist()  # 将Excel内容转化为列表存储
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    plt.figure(figsize=(6, 6))  # 图片尺寸大小
    X = np.arange(1, 9, 1)
    print(X)
    # X1 = ['DC', 'BC', 'CC', 'CLD', 'QLC', 'GSM', 'KSGC', 'SLGC']
    plt.plot(X, Y[0], color="r", linewidth=2, linestyle="-",
             marker='*', markersize=7, markerfacecolor='r', label=r"DC")
    plt.plot(X, Y[1], color="darkorange", linewidth=2, linestyle="-", marker='^',
             markersize=6, markerfacecolor='darkorange', label=r"BC")
    plt.plot(X, Y[2], color="g", linewidth=2, linestyle="-",
             marker='P', markersize=6, markerfacecolor='g', label=r"CC")
    plt.plot(X, Y[3], color="m", linewidth=2, linestyle="-",
             marker='d', markersize=6, markerfacecolor='m', label=r"QLC")
    plt.plot(X, Y[4], color="y", linewidth=2, linestyle="-",
             marker='X', markersize=6, markerfacecolor='y', label=r"GSM")
    plt.plot(X, Y[5], color="lime", linewidth=2, linestyle="-",
             marker='h', markersize=6, markerfacecolor='lime', label=r"KSGC")
    plt.plot(X, Y[6], color="b", linewidth=2, linestyle="-",
             marker='s', markersize=6, markerfacecolor='b', label=r"ALSI")
    plt.plot(X, Y[7], color="k", linewidth=2, linestyle="-",
             marker='o', markersize=6, markerfacecolor='k', label=r"SLGC")
    # 绘制垂直于X轴的直线
    # plt.vlines([0.0530], 0.2, 1, linewidth=1, colors='darkgrey', linestyles='dashed')
    '''设置坐标轴标签'''
    # front是标签属性：包括字体、大小等
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13,
            }
    plt.xlabel("$\\beta$", font)
    plt.ylabel("$\\tau$", font)
    plt.title(r'PGP', family='Times New Roman', fontsize=14, weight='bold')

    # plt.rc('font', family='Times New Roman')#定义坐标轴字体
    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')
    '''设置坐标轴以固定间隔显示刻度'''
    x_major_locator = MultipleLocator(1)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    '''设置坐标轴显示范围'''
    plt.xlim(0, 9)
    plt.ylim(0.45, 0.95)

    '''设置坐标轴线粗细'''
    ax = plt.gca()  # 获得坐标轴的句柄
    ax.spines['bottom'].set_linewidth(1.3)  ###设置底部坐标轴的粗细
    ax.spines['left'].set_linewidth(1.3)  ####设置左边坐标轴的粗细
    ax.spines['top'].set_linewidth(1.3)  ###设置上部坐标轴的粗细
    ax.spines['right'].set_linewidth(1.3)  ####设置右边坐标轴的粗细
    font1 = {'family': 'Times New Roman',
             'weight': 'bold',
             'size': 13,
             }  # normal,bold,heavy,black
    plt.legend(loc="lower right", edgecolor='black', prop=font1, framealpha=1)  # 图例设置##framealpha:图例框架的透明度
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\kendall_average.pdf', format='pdf',
                dpi=300, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()


def main12():
    # main1()
    # main2()
    # main3()
    # main4()
    #
    # main6()
    # main7()
    # main8()
    #
    # main10()
    # main11()
    averge_kendall()


if __name__ == "__main__":
    main12()
