from generalized_centrality.get_generalized import *
'''读取MATLAB中的邻接矩阵Excel文件'''
# G = nx.read_gml("data/Email.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)


MM = pd.read_excel("data/Hamster.xlsx",header=None)
N = nx.from_numpy_matrix(np.array(MM))
A = nx.to_scipy_sparse_array(N).todense()#构造邻接矩阵
G = nx.to_networkx_graph(A)


H_1 = []
H_1.extend([degree(G), betweenness(G), closeness(G), CLD(G,A), QLC(G,A),
            GSM(G), KSGC(G), ALSI(G),generalized_centrality_Hamster(G,A)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
#print('H_1',H_1)
H_2=[]
for i in H_1:
    H_2.append(MR(i))
print('Hamster',H_2)
result = pd.DataFrame(H_2)
#声明一个读写对象
writer=pd.ExcelWriter("output/MR_2.xlsx",engine='openpyxl',mode='a')
result.to_excel(writer,sheet_name='Hamster',index=False)
#writer.save()#保存读写的内容
writer.close()