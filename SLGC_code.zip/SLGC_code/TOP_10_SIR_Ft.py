import pandas as pd
import random
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy.stats import kendalltau

'''求距离矩阵'''


def distance(G):
    length = dict(nx.all_pairs_shortest_path_length(G))
    # print(length)
    distance_matrix = np.zeros([len(G), len(G)])
    for key1, value1 in length.items():
        for key2, value2 in value1.items():
            distance_matrix[key1][key2] = length[key1][key2]
    return distance_matrix


# result = pd.DataFrame(distance(G))
# result.to_excel('output/distance_matrix.xlsx',index=False)
'''求K核值'''


def k_shell(G):
    '''计算每个节点的KS值'''
    G1 = G.copy()  # 目的是对G1进行删点和边的操作，对G没有影响

    def k_shell_1(G1):
        importance_dict = {}
        level = 1
        while len(G1.degree):
            importance_dict[level] = []
            while True:
                level_node_list = []
                for item in G1.degree:
                    if item[1] <= level:
                        level_node_list.append(item[0])
                G1.remove_nodes_from(level_node_list)  # 从G中移除节点，移除完后为空，导致后续函数调用G报列表索引越界，k_sheel(G)放到最后
                importance_dict[level].extend(level_node_list)
                if not len(G1.degree):
                    return importance_dict
                if min(G1.degree, key=lambda x: x[1])[1] > level:
                    break
            level = min(G1.degree, key=lambda x: x[1])[1]
        # print('importance_dict',importance_dict)
        return importance_dict

    a = k_shell_1(G1)
    # print('a',a)
    H = {}
    for x, y in a.items():
        for z in y:
            H[z] = x
    # print('H',H)
    H_reverse = sorted(H.items(), key=lambda x: x[0])
    # print(dict(H_reverse))
    KS1 = list(dict(H_reverse).values())
    # print('KS1',KS1)
    return KS1


# print(k_shell(G))
'''求节点度'''


def node_degree(G):
    '''求度序列'''
    D1 = nx.degree(G)
    # print('D1=',D1)
    D = []  # D存放每个节点的di值
    for i in range(len(G)):
        D.append(D1[i])
    # print('D=', D)
    return D


'''求节点的聚类系数'''


def Cluster(G):
    C = nx.clustering(G)
    CL = []
    for i in C.values():
        CL.append(i)
    return CL


def dis_average(G):
    d6 = list(nx.all_pairs_shortest_path_length(G))  # 所有节点对之间的最短路径长度
    # print('d6',d6)
    a = []
    for n in range(len(G.nodes)):
        a1 = d6[n][1]
        # print('a1',a1)
        for k in a1.values():
            a.append(k)
    # print(a)
    total = 0
    for i in range(len(a)):
        total = total + a[i]
    dis_average = total / (len(G) * (len(G) - 1))
    # print('连通图或者非连通图的平均距离', dis_average)
    return dis_average


def degree(G):
    # 计算度中心性,降序
    dc = nx.algorithms.centrality.degree_centrality(G)
    # print('dc',dc)
    dc_reverse = dict(sorted(dc.items(), key=lambda x: x[1], reverse=True))
    # print('dc_reverse',dc_reverse)
    dc_1 = list(dc_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1',dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('DC',degree(G))

def betweenness(G):
    # 计算介数中心性,降序
    dc = nx.betweenness_centrality(G)
    # print('dc',dc)
    dc_reverse = dict(sorted(dc.items(), key=lambda x: x[1], reverse=True))
    # print('dc_reverse',dc_reverse)
    dc_1 = list(dc_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1',dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('BC',betweenness(G))

def closeness(G):
    # 计算接近中心性,降序
    dc = nx.closeness_centrality(G)
    # print('dc',dc)
    dc_reverse = dict(sorted(dc.items(), key=lambda x: x[1], reverse=True))
    # print('dc_reverse',dc_reverse)
    dc_1 = list(dc_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1',dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('CC',closeness(G))

def CLD(G, A):
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=', M)
    DM = [0] * len(G)
    for i in range(len(G)):
        for j in range(len(G)):
            if A[i, j] == 1:
                DM[i] += M[j]
    # print('DM',DM)
    C = []
    for i in range(len(G)):
        C.append(nx.clustering(G, i))  # 计算每个节点的聚类系数
    # print('C',C)
    CLD = []
    for i in range(len(G)):
        CLD.append((1 + C[i]) * DM[i])
    # print('CLD', CLD)
    CLD_normalized = []
    for i in range(len(G)):
        CLD_normalized.append(CLD[i] / max(CLD))
    # print('CLD_normalized',CLD_normalized)
    dict1 = dict(enumerate(CLD_normalized))  # 将列表转化为字典
    # print('dict1',dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse',CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('CLD',CLD(G,A))


def QLC(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append(j ** 2 + j + 2 * W[i])
    C_normalized = []
    for i in range(len(A)):
        C_normalized.append(C[i] / max(C))  # 归一化，除最大值
    # print('C',C)
    # print('C_normalized', C_normalized)
    dict1 = dict(enumerate(C_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('QLC',QLC(G,A))

def GSM(G):
    '''求SI'''
    dis = distance(G)
    ks = k_shell(G)
    SI = []
    for i in range(len(G)):
        SI.append(math.exp(ks[i] / len(G)))
    # print('SI',SI)
    '''求GI'''
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += ks[j] / dis[i][j]
        GI.append(SS)
    # print('GI',GI)
    '''求GSM'''
    GSM = []
    for i in range(len(G)):
        GSM.append(SI[i] * GI[i])
    # print('GSM',GSM)
    GSM_normalized = []
    for i in range(len(GSM)):
        GSM_normalized.append(GSM[i] / max(GSM))  # 归一化，除最大值
    dict1 = dict(enumerate(GSM_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('GSM',GSM(G))

def LGC(G):
    D = node_degree(G)
    dis = distance(G)
    '''求LI'''
    LI = []
    for i in range(len(G)):
        LI.append(D[i] / len(G))
    # print('LI',LI)
    '''求GI'''
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(D[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI',GI)
    '''求LGC'''
    LGC = []
    for i in range(len(G)):
        LGC.append(LI[i] * GI[i])
    # print('LGC',LGC)
    LGC_normalized = []
    for i in range(len(LGC)):
        LGC_normalized.append(LGC[i] / max(LGC))  # 归一化，除最大值
    dict1 = dict(enumerate(LGC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('LGC',LGC(G))

def ALSI(G):
    k = node_degree(G)
    # print('度', k)
    ks = k_shell(G)
    # print('K核', ks)
    ks_max = max(ks)
    ks_min = min(ks)
    # print('ks_max', ks_max, 'ks_min', ks_min)

    neighb = []
    for i in G.nodes:
        list1 = list(G.neighbors(i))
        neighb.append(list1)

    # print(neighb)

    def jaccard(a, b):
        A1 = len(set(a).union(set(b)))
        B1 = len(set(a).intersection(set(b)))
        if A1 != 0:
            W = B1 / A1
        else:
            W = 0
        return W

    jaccard_matrix = np.zeros([len(G), len(G)])
    for i in range(len(G)):
        for j in range(len(G)):
            jaccard_matrix[i][j] = jaccard(neighb[i], neighb[j])
    # print('jaccard_matrix', jaccard_matrix)

    PP = []
    for i in range(len(G)):
        H = []
        for j in neighb[i]:
            H1 = ks[j] * jaccard_matrix[i][j] + k[j] * ks[j]
            if ks[j] < ks[i]:
                I = H1 / (ks_max + ks_min)
            elif ks[j] > ks[i]:
                I = H1 / (ks_max - ks_min)
            else:
                I = H1 / ks_max
            H.append(I)
        # print('H',H)
        PP.append(sum(H))
    # print('PP', PP)

    KK = []
    for i in range(len(G)):
        HH = k[i] + ks[i] / ks_max
        KK.append(HH)
    # print('KK', KK)

    total = []
    for i in range(len(G)):
        total.append(PP[i] / max(k) + KK[i])
    # print('total', total)

    ALSI_normalized = []
    for i in range(len(G)):
        ALSI_normalized.append(total[i] / max(total))
    # print('ALSI_normalized', ALSI_normalized)
    dict1 = dict(enumerate(ALSI_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


def KSGC(G):
    k = node_degree(G)
    # print(k)
    ks = k_shell(G)
    # print(ks)
    ks_max = max(ks)
    ks_min = min(ks)
    # print(ks_max, ks_min)
    dis = distance(G)
    # print(dis)
    dis_aver = dis_average(G)
    # print(dis_aver)

    ks_1 = ks_max - ks_min
    # print(ks_1)
    c = np.zeros([len(G), len(G)])
    for i in range(len(G)):
        for j in range(len(G)):
            c[i][j] = math.exp((ks[i] - ks[j]) / ks_1)
    # print('C', c)

    F = np.zeros([len(G), len(G)])
    for i in range(len(G)):
        for j in range(len(G)):
            if i == j or dis[i][j] == 0:
                F[i][j] = 0
            else:
                F[i][j] = c[i][j] * (k[i] * k[j] / dis[i][j] ** 2)
    # print('F', F)

    KSGC = []
    for i in range(len(G)):
        F1 = 0
        for j in range(len(G)):
            if dis[i][j] <= 0.5 * dis_aver:
                F1 += F[i][j]
        KSGC.append(F1)
    # print(KSGC)
    CLD_normalized = []
    for i in range(len(G)):
        CLD_normalized.append(KSGC[i] / max(KSGC))
    # print('CLD_normalized',CLD_normalized)
    dict1 = dict(enumerate(CLD_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print(KSGC(G))

def generalized_centrality_Dolphins(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.4
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Dolphins',generalized_centrality_Dolphins(G,A))

def generalized_centrality_Jazz(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.7
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Jazz',generalized_centrality_Jazz(G,A))

def generalized_centrality_USAir(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.3
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('USAir',generalized_centrality_USAir(G,A))

def generalized_centrality_EEC(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.1
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('EEC',generalized_centrality_EEC(G,A))

def generalized_centrality_Roget(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.6
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Roget',generalized_centrality_Roget(G,A))

def generalized_centrality_Email(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Email',generalized_centrality_Email(G,A))

def generalized_centrality_Stelzl(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.6
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Stelzl',generalized_centrality_Stelzl(G,A))

def generalized_centrality_Hamster(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.9
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Hamster',generalized_centrality_Hamster(G,A))

def generalized_centrality_Power(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


# print('Power',generalized_centrality_Power(G,A))

def generalized_centrality_Facebook(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0.9
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2


def generalized_centrality_PGP(G, A):
    '''求度序列'''
    D = nx.degree(G)
    # print('D=',D)
    # M存放每个节点的di值
    M = []
    for i in range(len(G)):
        M.append(D[i])
    # print('M=',M)

    '''求邻居的度之和'''
    W = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                W[i] += M[j]
    # print('W=',W)

    '''计算广义能量中心性'''
    a = 0
    C = []
    for i, j in enumerate(M):  # enumerate多用于在for循环中得到计数，利用它可以同时获得索引(i)和值(j)，即需要index和value值的时候可以使用enumerate
        C.append((a ** 2) * (j ** 2) + (a ** 2 - 4 * a + 2) * j + (2 * (a ** 2) * W[i]))
        # C_normalized=C/max(C)#归一化，除最大值
    # print('C',a,C)
    C1 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C1[i] += C[j]
    C2 = [0] * len(A)  # 一行n列的空矩阵
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                C2[i] += C1[j]
    # print('C2', C2)
    E1 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E1[i] += -((C[j] / C1[i]) * (math.log(C[j] / C1[i], 2)))
    # print('E1',E1)
    E2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                E2[i] += -((C1[j] / C2[i]) * (math.log(C1[j] / C2[i], 2)))
    # print('E2',E2)
    EEC1 = [0] * len(A)
    for i in range(len(A)):
        # EEC1[i]=E1[i]+(C2[i]/max(C2))*E2[i]
        if C1[i] + C2[i] == 0:
            EEC1[i] = 0
        else:
            EEC1[i] = E1[i] + (C2[i] / (C1[i] + C2[i])) * E2[i]
    # print('EEC1',EEC1)
    EEC2 = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC2[i] += EEC1[j]
    # print('EEC2', EEC2)
    EEC = [0] * len(A)
    for i in range(len(A)):
        for j in range(len(A)):
            if A[i, j] == 1:
                EEC[i] += EEC2[j]
    # print('EEC',EEC)
    '''求全局属性GI'''
    dis = distance(G)
    ks = k_shell(G)
    Cl = Cluster(G)
    GI = []
    for i in range(len(G)):
        SS = 0
        for j in range(len(G)):
            if i != j and dis[i][j] != 0:
                SS += (math.sqrt(Cl[j] + 1)) / dis[i][j]
        GI.append(SS)
    # print('GI2',GI)
    '''求总的影响力'''
    GEEC = []
    for i in range(len(G)):
        GEEC.append(EEC[i] * GI[i])
    # print('GEEC222',GEEC)
    GEEC_normalized = []
    for i in range(len(A)):
        GEEC_normalized.append(GEEC[i] / max(GEEC))
    # print('GEEC_normalized', GEEC_normalized)
    dict1 = dict(enumerate(GEEC_normalized))  # 将列表转化为字典
    # print('dict1', dict1)
    CLD_reverse = dict(sorted(dict1.items(), key=lambda x: x[1], reverse=True))
    # print('CLD_reverse', CLD_reverse)
    dc_1 = list(CLD_reverse.keys())  # 每个元素加1
    dc_2 = dc_1[0:10]  # 取前十个重要的节点
    # print('dc_1', dc_1)
    # print('dc_2', dc_2)
    return dc_2
