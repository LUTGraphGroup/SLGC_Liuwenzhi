import numpy as np
import pandas as pd
import matplotlib.pyplot as plt          #导入库
from mpl_toolkits.mplot3d import Axes3D  #导入库
import matplotlib.cm as cm
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib.colors import ListedColormap

date = pd.read_excel('output/SIR_kendall_1.xlsx', sheet_name='optimal1', header=0)  # header=0删除了第一行
print(date)
H = []
for i in range(date.shape[1]):  # 遍历列
    Y1 = []
    for j in range(date.shape[0]):  # 遍历行
        Y1.append(date[i][j])
    H.append(Y1)
print(H)

X1=np.arange(0,8,1)
Y1=np.arange(0,9,1)


Z=np.zeros([len(Y1), len(X1)])
print(Z)

for i in range(len(Y1)):
    for j in range(len(X1)):
        Z[i,j]=H[i][j]
print(Z)
xx,yy=np.meshgrid(X1, Y1) #网格化坐标
X1, Y1=xx.ravel(), yy.ravel() #矩阵扁平化
dz=np.zeros_like(X1)#设置柱状图的底端位值
Z=Z.ravel()#扁平化矩阵
dx =0.4 # 每一个柱子的长
dy =0.4#每一个柱子的宽
# 绘图设置
ax = plt.subplot(projection='3d')  # 三维坐标轴

cmap=cm.get_cmap('rainbow')#色带颜色变化
norm=plt.Normalize(np.min(Z),np.max(Z))#根据数据范围得到正则化规则
sm=cm.ScalarMappable(norm=norm,cmap=cmap)
plt.colorbar(sm)#显示对应数值的颜色条,创建色阶条
ax.bar3d(X1, Y1, dz, dx, dy, Z, shade=True, color=sm.to_rgba(Z))

# 坐标轴设置
x_locator = MultipleLocator(1)
ax.xaxis.set_major_locator(x_locator)#将x轴坐标的间隔设置为0.1
y_locator = MultipleLocator(1)
ax.yaxis.set_major_locator(y_locator)#将y轴坐标的间隔设置为0.02
font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13}
ax.set_xlabel('X',font)
# ax.set_ylabel('Y')
# ax.set_zlabel('Z')
# 将三维的灰色背景面换成白色
ax.w_xaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
ax.w_yaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
ax.w_zaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
X2=np.arange(1,9,1)
Y2=np.arange(1,10,1)
X=['DC','BC','CC','CLD','QLC','GSM','KSGC','SLGC']
Y=['Dolphins','Jazz','USAir','EEC',	'Email','Stelzl','Hamster','Facebook','PGP']
plt.xticks(X2,X)
plt.yticks(Y2,Y)
plt.xlim(0, 8)
plt.ylim(0, 9)

plt.savefig('E:\pythonProject\generalized_centrality\Photo\Parameter.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
plt.show()

