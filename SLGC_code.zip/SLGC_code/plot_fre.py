import numpy as np
import pandas as pd
import numpy as np	# 加载数学库用于函数描述
import matplotlib
import matplotlib.pyplot as plt
from matplotlib import style
from matplotlib.ticker import MultipleLocator, FormatStrFormatter
from matplotlib.patches import ConnectionPatch
from generalized_centrality.get_generalized import *
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

'''读取MATLAB中的邻接矩阵Excel文件'''
# G = nx.read_gml("data/Dolphins.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)
#
#
# G1 = nx.read_gml("data/Jazz.gml", label='id')
# A1 = nx.to_scipy_sparse_array(G1).todense()#构造邻接矩阵
# G1 = nx.to_networkx_graph(A1)
#
#
# G2 = nx.read_gml("data/USAir.gml", label='id')
# A2 = nx.to_scipy_sparse_array(G2).todense()#构造邻接矩阵
# G2 = nx.to_networkx_graph(A2)
#
#
# MM3 = pd.read_excel("data/EEC.xlsx",header=None)
# N3 = nx.from_numpy_matrix(np.array(MM3))
# A3 = nx.to_scipy_sparse_array(N3).todense()#构造邻接矩阵
# G3 = nx.to_networkx_graph(A3)


# MM4 = pd.read_excel("data/Roget.xlsx",header=None)
# N4 = nx.from_numpy_matrix(np.array(MM4))
# A4 = nx.to_scipy_sparse_array(N4).todense()#构造邻接矩阵
# G4 = nx.to_networkx_graph(A4)


# G5 = nx.read_gml("data/Email.gml", label='id')
# A5 = nx.to_scipy_sparse_array(G5).todense()#构造邻接矩阵
# G5 = nx.to_networkx_graph(A5)
#
#
# MM6 = pd.read_excel("data/Stelzl.xlsx",header=None)
# N6 = nx.from_numpy_matrix(np.array(MM6))
# A6 = nx.to_scipy_sparse_array(N6).todense()#构造邻接矩阵
# G6 = nx.to_networkx_graph(A6)
#
#
# MM7 = pd.read_excel("data/Hamster.xlsx",header=None)
# N7 = nx.from_numpy_matrix(np.array(MM7))
# A7 = nx.to_scipy_sparse_array(N7).todense()#构造邻接矩阵
# G7 = nx.to_networkx_graph(A7)


# MM8 = pd.read_excel("data/Power.xlsx",header=None)
# N8 = nx.from_numpy_matrix(np.array(MM8))
# A8 = nx.to_scipy_sparse_array(N8).todense()#构造邻接矩阵
# G8 = nx.to_networkx_graph(A8)


# MM9 = pd.read_excel("data/Yeast.xlsx",header=None)
# N9 = nx.from_numpy_matrix(np.array(MM9))
# A9 = nx.to_scipy_sparse_array(N9).todense()#构造邻接矩阵
# G9 = nx.to_networkx_graph(A9)

# MM10 = pd.read_excel("data/Facebook.xlsx",header=None)
# N10 = nx.from_numpy_matrix(np.array(MM10))
# A10 = nx.to_scipy_sparse_array(N10).todense()#构造邻接矩阵
# G10 = nx.to_networkx_graph(A10)
#
MM11 = pd.read_excel("data/PGP.xlsx",header=None)
N11 = nx.from_numpy_matrix(np.array(MM11))
A11 = nx.to_scipy_sparse_array(N11).todense()#构造邻接矩阵
G11 = nx.to_networkx_graph(A11)

# MM12 = pd.read_excel("data/Sex.xlsx",header=None)
# N12 = nx.from_numpy_matrix(np.array(MM12))
# A12 = nx.to_scipy_sparse_array(N12).todense()#构造邻接矩阵
# G12 = nx.to_networkx_graph(A12)



def func1():
    H_1 = []
    H_3 = []
    H_4 = []
    H_2=[]
    H_1.extend([degree(G), betweenness(G), closeness(G), QLC(G,A),
            GSM(G), KSGC(G), ALSI(G), generalized_centrality_Dolphins(G,A)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=50,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=40,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+',s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c = 'w', marker = '>', edgecolors = 'm', linewidths = 1.5, norm = 1, s = 60, label = r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x',s=40,label=r"SLGC")

    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Dolphins', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(10)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(0, 62)
    plt.ylim(0, 10)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="50%", height="45%", loc='upper left',
                       bbox_to_anchor=(0.2, 0.45, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 50
    zone_right = 59

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(45, 61)
    axins.set_ylim(0, 2)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Dolphins.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func1()

def func2():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G1), betweenness(G1), closeness(G1), QLC(G1,A1),
            GSM(G1), KSGC(G1), ALSI(G1),generalized_centrality_Jazz(G1,A1)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig, ax1 = plt.subplots(1, 1, figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=50,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=40,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Jazz', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(40)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)
    plt.xlim(0, 200)
    plt.ylim(0, 16)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="60%", height="48%", loc='upper left',
                       bbox_to_anchor=(0.1, 0.45, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    #（x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 179
    zone_right = 194

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right],H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right],H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(180, 196)
    axins.set_ylim(0,2)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Jazz.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func2()

def func3():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G2), betweenness(G2), closeness(G2), QLC(G2,A2),
            GSM(G2), KSGC(G2), ALSI(G2),generalized_centrality_USAir(G2,A2)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=50,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=40,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'USAir', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(50)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)
    plt.xlim(0, 300)
    plt.ylim(-3, 140)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="80%", height="60%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.18, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(240, 290)
    axins.set_ylim(0, 3)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_USAir.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func3()

def func4():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G3), betweenness(G3), closeness(G3), QLC(G3,A3),
            GSM(G3), KSGC(G3), ALSI(G3),generalized_centrality_EEC(G3,A3)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=50,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=40,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'EEC', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)
    plt.xlim(0, 1000)
    plt.ylim(-3, 160)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="70%", height="60%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.18, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(935, 965)
    axins.set_ylim(0, 3)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_EEC.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func4()

def func5():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G4), betweenness(G4), closeness(G4), CLD(G4,A4), QLC(G4,A4),
            GSM(G4), LGC(G4), generalized_centrality_Roget(G4,A4)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=70,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=40,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"CLD")
    plt.scatter(H_5[4], H_3[4], c='w', marker='>',edgecolors='m',linewidths=1.5,norm=1,s=60, label=r"QLC")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+',s=80, label=r"GSM")
    plt.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x',s=40,label=r"GEEC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Roget', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)
    plt.xlim(-10, 1010)
    plt.ylim(-3, 120)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="60%", height="40%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.2, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"CLD")
    axins.scatter(H_5[4], H_3[4], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"QLC")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"GSM")
    axins.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"GEEC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(970, 995)
    axins.set_ylim(0, 2)

    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Roget.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func5()

def func6():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G5), betweenness(G5), closeness(G5), QLC(G5,A5),
            GSM(G5), KSGC(G5), ALSI(G5),generalized_centrality_Email(G5,A5)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=70,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=40,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Email', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-10, 1140)
    plt.ylim(-5, 205)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="80%", height="60%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.18, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1060, 1110)
    axins.set_ylim(0,4)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Email.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func6()

def func7():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G6), betweenness(G6), closeness(G6), QLC(G6,A6),
            GSM(G6), KSGC(G6), ALSI(G6),generalized_centrality_Stelzl(G6,A6)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=70,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=60,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Stelzl', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(200)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-15, 1250)
    plt.ylim(-30, 830)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="80%", height="60%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.18, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1160, 1222)
    axins.set_ylim(0, 4)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Stelzl.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func7()


def func8():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G7), betweenness(G7), closeness(G7),QLC(G7,A7),
            GSM(G7), KSGC(G7), ALSI(G7),generalized_centrality_Hamster(G7,A7)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=70,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=60,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Hamster', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(300)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-15, 1800)
    plt.ylim(-30, 1000)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="60%", height="60%", loc='upper left',
                       bbox_to_anchor=(0.1, 0.45, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1620, 1685)
    axins.set_ylim(0, 6)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Hamster.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func8()

def func9():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G8), betweenness(G8), closeness(G8), CLD(G8,A8), QLC(G8,A8),
            GSM(G8), LGC(G8), generalized_centrality_Power(G8,A8)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=60,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=60,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"CLD")
    plt.scatter(H_5[4], H_3[4], c='w', marker='>',edgecolors='m',linewidths=1.5,norm=1,s=60, label=r"QLC")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+',s=80, label=r"GSM")
    plt.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x',s=40,label=r"GEEC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Power', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(900)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-100, 4600)
    plt.ylim(-50, 1700)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="60%", height="40%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.2, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"CLD")
    axins.scatter(H_5[4], H_3[4], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"QLC")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"GSM")
    axins.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"GEEC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(4460, 4485)
    axins.set_ylim(0, 2)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Power.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func9()

def func10():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G9), betweenness(G9), closeness(G9), CLD(G9,A9), QLC(G9,A9),
            GSM(G9), LGC(G9), generalized_centrality_Yeast(G9,A9)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=60,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=60,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"CLD")
    plt.scatter(H_5[4], H_3[4], c='w', marker='>',edgecolors='m',linewidths=1.5,norm=1,s=60, label=r"QLC")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+',s=80, label=r"GSM")
    plt.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x',s=40,label=r"GEEC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Yeast', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(400)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-30, 2000)
    plt.ylim(-30, 1000)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="80%", height="60%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.18, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"CLD")
    axins.scatter(H_5[4], H_3[4], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"QLC")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"GSM")
    axins.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"GEEC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(1800, 1870)
    axins.set_ylim(0, 8)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Yeast.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func9()

def func11():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G10), betweenness(G10), closeness(G10), QLC(G10,A10),
            GSM(G10), KSGC(G10), ALSI(G10),generalized_centrality_Facebook(G10,A10)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=60,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=60,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Facebook', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(800)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-100, 4000)
    plt.ylim(-10, 360)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="80%", height="60%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.18, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(3780, 3880)
    axins.set_ylim(0, 8)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Facebook.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func9()

def func12():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G11), betweenness(G11), closeness(G11), QLC(G11,A11),
            GSM(G11), KSGC(G11), ALSI(G11),generalized_centrality_PGP(G11,A11)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=60,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=60,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"QLC")
    plt.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    plt.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'PGP', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(1700)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-200, 8600)
    plt.ylim(-200, 5800)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="80%", height="60%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.18, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"QLC")
    axins.scatter(H_5[4], H_3[4], c='k', marker='1', s=80, label=r"GSM")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"KSGC")
    axins.scatter(H_5[6], H_3[6], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"ALSI")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"SLGC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(8200, 8380)
    axins.set_ylim(0, 6)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_PGP.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func9()

def func13():
    H_1 = []
    H_3 = []
    H_4 = []
    H_1.extend([degree(G12), betweenness(G12), closeness(G12), CLD(G12,A12), QLC(G12,A12),
            GSM(G12), LGC(G12), generalized_centrality_Sex(G12,A12)])#generalized_centrality_Dolphins(G,A)不同网络a取值不同，需要换成对应的
    for i in H_1:
        H_3.append(frequency(i))
    print('H_3', H_3)#存放Y轴数据
    H_2 = []
    for i in H_3:
        H_2.append(max(i))
    print('MAX', H_2)
    for i in range(len(H_3)):  # 求每个指标的排序级别数
        H_4.append(len(H_3[i]))
    print('H_4', H_4)
    H_5 = []
    for i in H_4:
        # print(i)
        X2 = list(np.linspace(1, i, i))
        H_5.append(X2)
    print('H_5', H_5)#存放X轴数据
    plt.rcParams['xtick.direction'] = 'in'  # 将X轴刻度线的方向设置向内
    plt.rcParams['ytick.direction'] = 'in'  # 将Y轴刻度线的方向设置向内
    fig,ax1=plt.subplots(1,1,figsize=(6, 6))  # 图片尺寸大小
    plt.scatter(H_5[0], H_3[0],  c='w', marker='o',edgecolors='orange',linewidths=1.5,norm=1,s=50,label=r"DC")#s控制点的大小，c为点的颜色(w为白色)，edgecolors边的颜色
    plt.scatter(H_5[1], H_3[1], c='w', marker='v',edgecolors='g',linewidths=1.5,norm=1,s=60,label=r"BC")#norm,数据亮度0-1
    plt.scatter(H_5[2], H_3[2], c='w', marker='s',edgecolors='b',linewidths=1.5,norm=1,s=60,label=r"CC")
    plt.scatter(H_5[3], H_3[3], c='w',marker='*', edgecolors='y',linewidths=1.5,norm=1,s=100, label=r"CLD")
    plt.scatter(H_5[4], H_3[4], c='w', marker='>',edgecolors='m',linewidths=1.5,norm=1,s=60, label=r"QLC")
    plt.scatter(H_5[5], H_3[5], c='c', marker='+',s=80, label=r"GSM")
    plt.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    plt.scatter(H_5[7], H_3[7], c='r', marker='x',s=40,label=r"GEEC")
    font = {'family': 'Times New Roman',
            'weight': 'bold',
            'size': 13} # normal,bold,heavy,black
    plt.xlabel('Rank', font)
    plt.ylabel('Frequency',font)
    plt.title(r'Sex', family='Times New Roman',fontsize=14,weight='bold')

    plt.legend(loc="best",edgecolor='black',prop=font,framealpha=1)# 图例设置##framealpha:图例框架的透明度


    plt.xticks(fontsize=14, family='Times New Roman', weight='bold')  # 设置坐标轴刻度字号
    plt.yticks(fontsize=14, family='Times New Roman', weight='bold')

    ax=plt.gca()
    ax.spines['bottom'].set_linewidth(1.3)  # 设置底部线的宽度
    ax.spines['left'].set_linewidth(1.3)  # 设置左边线的宽度
    ax.spines['right'].set_linewidth(1.3)  # 设置右边线的宽度
    ax.spines['top'].set_linewidth(1.3)  # 设置上面线的宽度
    '''设置坐标轴刻度大小'''
    x_major_locator = MultipleLocator(900)  # 以每0.05显示
    # y_major_locator = MultipleLocator(3)  # 以每3显示
    ax = plt.gca()
    ax.xaxis.set_major_locator(x_major_locator)
    # ax.yaxis.set_major_locator(y_major_locator)

    plt.xlim(-100, 4600)
    plt.ylim(-50, 1700)

    '''添加局部放大图'''
    # 绘制缩放图
    axins = inset_axes(ax1, width="60%", height="40%", loc='lower right',
                       bbox_to_anchor=(0.01, 0.2, 0.9, 0.5),
                       bbox_transform=ax.transAxes)
    # （x0, y0, width, height），上述代码的含义是：以父坐标系中的x0=0.2*x，y0=0.2*y为左下角起点，嵌入一个宽度为0.2*x，高度为0.3*y的子坐标系，其中x和y分别为父坐标系的坐标轴范围。
    # 在缩放图中也绘制主图所有内容，然后根据限制横纵坐标来达成局部显示的目的
    axins.scatter(H_5[0], H_3[0], c='w', marker='o', edgecolors='orange', linewidths=1.5, norm=1, s=50,
                  label=r"DC")
    axins.scatter(H_5[1], H_3[1], c='w', marker='v', edgecolors='g', linewidths=1.5, norm=1, s=50,
                  label=r"BC")
    axins.scatter(H_5[2], H_3[2], c='w', marker='s', edgecolors='b', linewidths=1.5, norm=1, s=40, label=r"CC")
    axins.scatter(H_5[3], H_3[3], c='w', marker='*', edgecolors='y', linewidths=1.5, norm=1, s=100, label=r"CLD")
    axins.scatter(H_5[4], H_3[4], c='w', marker='>', edgecolors='m', linewidths=1.5, norm=1, s=60, label=r"QLC")
    axins.scatter(H_5[5], H_3[5], c='c', marker='+', s=80, label=r"GSM")
    axins.scatter(H_5[6], H_3[6], c='k', marker='1', s=80, label=r"LGC")
    axins.scatter(H_5[7], H_3[7], c='r', marker='x', s=40, label=r"GEEC")

    # 设置放大区间
    zone_left = 255
    zone_right = 285

    # 坐标轴的扩展比例（根据实际数据调整）
    x_ratio = 0.05  # x轴显示范围的扩展比例
    y_ratio = 0.05  # y轴显示范围的扩展比例

    # X轴的显示范围
    xlim0 = H_5[7][zone_left] - (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio
    xlim1 = H_5[7][zone_right] + (H_5[7][zone_right] - H_5[7][zone_left]) * x_ratio

    # Y轴的显示范围
    y = np.hstack((H_3[0][zone_left:zone_right], H_3[1][zone_left:zone_right],
                   H_3[2][zone_left:zone_right], H_3[3][zone_left:zone_right],
                   H_3[4][zone_left:zone_right], H_3[5][zone_left:zone_right],
                   H_3[6][zone_left:zone_right], H_3[7][zone_left:zone_right]))
    ylim0 = np.min(y) - (np.max(y) - np.min(y)) * y_ratio
    ylim1 = np.max(y) + (np.max(y) - np.min(y)) * y_ratio

    # 调整子坐标系的显示范围
    axins.set_xlim(4460, 4485)
    axins.set_ylim(0, 2)
    plt.savefig('E:\pythonProject\generalized_centrality\Photo\Fre_Sex.pdf', format='pdf',
                dpi=600, bbox_inches='tight')  # dpi 表示以高分辨率保存一个图片文件，pdf为文件格式，bbox_inches = 'tight'去掉空白
    plt.show()
# func9()

def func14():
    # func1()
    # func2()
    # func3()
    # func4()
    # func6()
    # func7()
    # func8()
    # func11()
    func12()

if __name__ == "__main__":
    func14()