import pandas as pd
import random
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import math
from scipy.stats import kendalltau
from networkx.algorithms.assortativity.connectivity import *
'''读取.gml文件'''
# G = nx.read_gml("data/Dolphins.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)


'''读取MATLAB中的邻接矩阵Excel文件'''
MM = pd.read_excel("data/PGP.xlsx",header=None)
N = nx.from_numpy_matrix(np.array(MM))
A = nx.to_scipy_sparse_array(N).todense()#构造邻接矩阵
G = nx.to_networkx_graph(A)


print('顶点和边数=',G)

d=nx.degree(G)
d1=dict(nx.degree(G))
d2=sum(d1.values())/len(G.nodes)
print('平均度=',d2)
print('最大度',max(d1.values()))

'''连通图的平均最短路径长度'''
p4=nx.average_shortest_path_length(G)
print('连通图的平均距离=',p4)

'''连通图或者非连通图的平均最短路径长度'''
d6=list(nx.all_pairs_shortest_path_length(G))#所有节点对之间的最短路径长度
#print('d6',d6)
a= []
for n in range(len(G.nodes)):
    a1 = d6[n][1]
    #print('a1',a1)
    for k in a1.values():
        a.append(k)
#print(a)
total=0
for i in range(len(a)):
    total = total + a[i]
#print('total',total)
print('连通图或者非连通图的平均距离',total/(len(G)*(len(G)-1)))

r=nx.degree_assortativity_coefficient(G)
print('同配系数=',r)

#平均聚类系数#
print('平均聚类系数=',nx.average_clustering(G))
# 全局聚类系数的区别
#print('全局聚类系数=',nx.transitivity(G))

list_1 = list(map(lambda x:x**2, d1.values()))
d3=sum(list_1)/len(G.nodes)
#print(list_1)
print('感染阈值：',d2/d3)