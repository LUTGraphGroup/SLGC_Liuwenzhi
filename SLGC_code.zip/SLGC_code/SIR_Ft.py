import random
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
from generalized_centrality.TOP_10_SIR_Ft import *
#易感状态state=0，感染状态state=1,恢复状态state=2

# G = nx.read_gml("data/Dolphins.gml", label='id')
# A = nx.to_scipy_sparse_array(G).todense()#构造邻接矩阵
# G = nx.to_networkx_graph(A)


MM = pd.read_excel("data/PGP.xlsx",header=None)
N = nx.from_numpy_matrix(np.array(MM))
A = nx.to_scipy_sparse_array(N).todense()#构造邻接矩阵
G = nx.to_networkx_graph(A)


H_1 = []
H_1.extend([degree(G), betweenness(G), closeness(G), QLC(G,A),
            GSM(G), KSGC(G), ALSI(G),generalized_centrality_PGP(G,A)])
print(H_1)
Fluence_mean1=[]
for i in H_1:#seed为中心性TOP10感染节点
    seed=i
    #print('seed', seed)

    N=1#实验的次数
    time = 30  # 模拟的时间
    Fluence_sum= [0] * time
    for i in range(N):
        #print('实验次数N',i)
        for edge in G.edges:
            #print(edge[0],edge[1])#edge[0]表示边的第一个顶点，edge[1]表示边的第二个顶点
            G.add_edge(edge[0], edge[1], weight=random.uniform(0, 1)) #给每条边赋一个0-1的权重 # 可不可以作为权值 病毒的感染能力
        # print(G.edges[0,1]['weight'])#边(0,1)的权重
        # print(G[0][1]['weight'])#边(0,1)的权重

        for node in G:
            G.add_node(node, state=0)  # 用state标识状态 state=0 未激活，state=1 激活,将G中所有节点的初始状态设置为0(易感状态)
        #print(G.nodes[33]['state'])

        all_infect_nodes = []  # 所有被感染的节点放在这里
        for i in seed:
            G.nodes[i]['state'] = 1  # 表示33是感染的
            all_infect_nodes.append(i)
        #print('all_infect_nodes',all_infect_nodes)
        #all_infect_nodes = []  # 所有被感染的节点放在这里
        #all_infect_nodes.append(seed)
        #print('all_infect_nodes',all_infect_nodes)

        all_recover_nodes = []  # 所有恢复的节点放在这里
        #print('all_recover_nodes',all_recover_nodes)

        infect_rate=0.05#设置感染率
        recover_rate=0#设置恢复率

        Fluence=[]#存放每个时间点的F(t)
        for i in range(time):
            new_infect = list()  # 存放新被感染的

            for v in all_infect_nodes:
                for nbr in G.neighbors(v):#节点v的邻居节点
                    if G.nodes[nbr]['state'] == 0:  # 如果这个邻居节点没被感染
                        edge_data = G.get_edge_data(v,nbr)
                        #print('edge_data',edge_data)
                        if edge_data['weight']<infect_rate:
                            G.nodes[nbr]['state'] = 1
                            new_infect.append(nbr)

            #print('new_infect',new_infect)
            all_infect_nodes.extend(new_infect)  # 将新感染的添加到
            #print('all_active_nodes:', all_infect_nodes)

            for k in all_infect_nodes:
                x = random.uniform(0, 1)
                if x < recover_rate and G.nodes[k]['state'] ==1:
                    all_recover_nodes.append(k)
                    all_infect_nodes.remove(k)
                    G.nodes[k]['state'] = 2
            #print('all_infect_nodes:', all_infect_nodes)
            #print('all_recover_nodes',all_recover_nodes)
            F_t=len(all_infect_nodes) +len(all_recover_nodes)
            Fluence.append(F_t)
            #print('F(t)',F_t)
            #print('%s time' % i + ' %s infect_nodes' % len(all_infect_nodes)
            # + ' %s recover_nodes' % len(all_recover_nodes) + ' %s F(t)' % F_t)
        #print('Fluence',Fluence)
        Fluence_sum = list(np.add(Fluence_sum, Fluence))
        #print('Fluence_sum', Fluence_sum)
    Fluence_mean=[x/N for x in Fluence_sum]
    print('Fluence_mean',Fluence_mean)
    #print(len(Fluence_mean))
    Fluence_mean1.append(Fluence_mean)
print('Fluence_mean1',Fluence_mean1)


"结果存储到excel"
TOP10_matrix = np.zeros([time, len(Fluence_mean1)])
for i in range(len(Fluence_mean1)):
    for j in range(time):
        TOP10_matrix[j][i] = Fluence_mean1[i][j]
print(TOP10_matrix)
result = pd.DataFrame(TOP10_matrix)
# 声明一个读写对象
writer = pd.ExcelWriter("output/TOP10_Ft.xlsx", engine='openpyxl', mode='a')
result.to_excel(writer, sheet_name='PGP', index=False)
writer.close()
